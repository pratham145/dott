import React from 'react'

const Dashboard = () => {
  return (
    <div className='flex justify-center items-center'>
      Welcome to StudyNotion
    </div>
  )
}

export default Dashboard
