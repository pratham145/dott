import React from 'react'

const Home = () => {
  return (
    <div className='flex justify-center items-center'>
      Home
    </div>
  )
}

export default Home
